import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Eye, EyeOff, Smartphone, Lock, Sparkles } from 'lucide-react';

export function LoginForm() {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    mobile: '',
    password: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle login logic here
    console.log('Login attempt:', formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="w-full max-w-sm mx-auto">
      {/* Colorful background decoration */}
      <div className="relative">
        <div className="absolute -top-8 -left-8 w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full opacity-60 blur-xl"></div>
        <div className="absolute -top-4 -right-6 w-12 h-12 bg-gradient-to-br from-blue-400 to-cyan-400 rounded-full opacity-60 blur-lg"></div>
        <div className="absolute top-20 -left-4 w-8 h-8 bg-gradient-to-br from-orange-400 to-yellow-400 rounded-full opacity-40 blur-md"></div>
        
        <Card className="relative backdrop-blur-sm bg-white/95 border border-white/20 shadow-2xl shadow-purple-500/10">
          <CardHeader className="space-y-3 text-center pb-8 pt-8">
            <div className="mx-auto w-16 h-16 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 rounded-2xl flex items-center justify-center mb-2 shadow-lg">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-3xl bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 bg-clip-text text-transparent">
              Welcome back
            </CardTitle>
            <CardDescription className="text-gray-600">
              Sign in to your account to continue
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6 pb-8">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-3">
                <Label htmlFor="mobile" className="text-gray-700 flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-purple-500" />
                  Mobile Number
                </Label>
                <div className="relative">
                  <Input
                    id="mobile"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={formData.mobile}
                    onChange={(e) => handleInputChange('mobile', e.target.value)}
                    required
                    className="h-14 pl-4 pr-4 border-2 border-gray-200 focus:border-purple-400 focus:ring-purple-400/20 focus:ring-4 transition-all duration-200 rounded-xl bg-gray-50/50 backdrop-blur-sm"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 via-pink-500/5 to-orange-500/5 rounded-xl pointer-events-none"></div>
                </div>
              </div>
              
              <div className="space-y-3">
                <Label htmlFor="password" className="text-gray-700 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-purple-500" />
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    required
                    className="h-14 pl-4 pr-14 border-2 border-gray-200 focus:border-purple-400 focus:ring-purple-400/20 focus:ring-4 transition-all duration-200 rounded-xl bg-gray-50/50 backdrop-blur-sm"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 via-pink-500/5 to-orange-500/5 rounded-xl pointer-events-none"></div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-2 h-10 w-10 rounded-lg hover:bg-purple-100/50 transition-colors"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5 text-purple-600" />
                    ) : (
                      <Eye className="h-5 w-5 text-purple-600" />
                    )}
                    <span className="sr-only">
                      {showPassword ? 'Hide password' : 'Show password'}
                    </span>
                  </Button>
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full h-14 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 hover:from-purple-600 hover:via-pink-600 hover:to-orange-600 text-white shadow-lg shadow-purple-500/25 rounded-xl transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
              >
                <span className="relative z-10">Sign In</span>
              </Button>
            </form>

            <div className="text-center">
              <Button 
                variant="link" 
                className="text-sm text-purple-600 hover:text-purple-700 p-0 h-auto transition-colors"
              >
                Forgot your password?
              </Button>
            </div>

            <div className="text-center text-sm text-gray-600">
              Don't have an account?{' '}
              <Button 
                variant="link" 
                className="p-0 h-auto text-purple-600 hover:text-purple-700 transition-colors"
              >
                Sign up
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}